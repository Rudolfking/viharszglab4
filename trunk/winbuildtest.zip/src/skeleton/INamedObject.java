package skeleton;
public interface INamedObject {

	String getName();

	void setName(String name);

}
