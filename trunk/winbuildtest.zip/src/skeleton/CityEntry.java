//import InitialClassDiagram.*;
package skeleton;
public class CityEntry extends Intersection {
	
	public CityEntry(String name,Logger logger,
			CustomReader input) {
		super(name,logger,
				input);
	}
}