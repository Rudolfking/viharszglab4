package skeleton;
public class Bank extends Intersection {
	public Bank(String name,Logger logger,
			CustomReader input) {
		super(name,logger,
				input);
	}
	
}