package skeleton;

public class CivilCar extends Vehicle {

	public CivilCar(String name,Cell cell, int ispeed,Logger logger,
			CustomReader input) {
		super(name,cell,ispeed);
	}	

}
