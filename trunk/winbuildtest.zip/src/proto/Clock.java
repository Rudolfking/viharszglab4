package proto;
public class Clock extends NamedObject {

	public Clock(String name) {
		super(name);
	}

	/**
	 * 
	 * @return
	 */
	public boolean tick() {
		throw new UnsupportedOperationException();
	}

}