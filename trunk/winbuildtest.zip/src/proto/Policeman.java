package proto;
public class Policeman extends Vehicle {

	private Robber wanted;

	/**
	 * 
	 * @param v
	 * @return 
	 */
	public void onTheSameRoad(Vehicle v) {
		throw new UnsupportedOperationException();
	}

}