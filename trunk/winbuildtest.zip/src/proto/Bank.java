package proto;
public class Bank extends Intersection {

	public Bank(String name) {
		super(name);
	}
	
}