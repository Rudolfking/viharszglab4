//import InitialClassDiagram.*;
package proto;
public class CityEntry extends Intersection {
	
	public CityEntry(String name) {
		super(name);
	}
}