//package InitialClassDiagram;
package proto;
public class Intersection extends Cell {

	private Cell[] nextCells;
	private Cell[] previousCells;

	public Intersection(String name) {
		super(name);
	}

	/**
	 * 
	 * @param c
	 * @return
	 */
	public void addNextCell(Cell c) {
		
	}

	/**
	 * 
	 * @param c
	 * @return
	 */
	public void addPreviousCell(Cell c) {
		
	}

}