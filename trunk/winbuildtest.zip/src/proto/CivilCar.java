package proto;
public class CivilCar extends Vehicle {
}