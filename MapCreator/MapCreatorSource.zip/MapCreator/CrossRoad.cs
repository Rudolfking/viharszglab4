﻿using System.Collections.Generic;
using System.Windows.Controls;

namespace MapCreator
{
    internal abstract class CrossRoad : IElement
    {
        public readonly List<IElement> OnTheRoad = new List<IElement>();

        public double Y { get; set; }

        public double X { get; set; }

        public double CornerLeft
        {
            get { return X - 21.2132; }
        }

        public double CornerTop
        {
            get { return Y - 21.2132; }
        }

        #region IElement Members

        public abstract void Draw(ref Canvas paintField, int fieldNum);
        public abstract void Draw(ref Canvas paintField, double x, double y);

        #endregion
    }
}