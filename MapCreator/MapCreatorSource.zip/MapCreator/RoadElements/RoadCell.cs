﻿using System;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace MapCreator.RoadElements
{
    internal class RoadCell : Container
    {
        public override void Draw(ref Canvas paintField, double x, double y)
        {
            throw new NotImplementedException();
        }

        public override void Draw(ref Canvas paintField, int fieldNum)
        {
            var rec = new Rectangle
                          {
                              Width = 30,
                              Height = 30,
                              Fill = new SolidColorBrush(Color.FromRgb(105, 125, 254)),
                              StrokeThickness = 1,
                              Stroke = new SolidColorBrush(Color.FromRgb(105, 125, 254))
                          };
            Canvas.SetLeft(rec, fieldNum*30);
            Canvas.SetTop(rec, 0);
            paintField.Children.Add(rec);
            foreach (var t in OnTheRoad)
            {
                t.Draw(ref paintField, fieldNum);
            }
        }
    }
}