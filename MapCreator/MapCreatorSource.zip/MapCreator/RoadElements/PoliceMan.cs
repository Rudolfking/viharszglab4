﻿using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace MapCreator.RoadElements
{
    internal class PoliceMan : IElement
    {
        #region IElement Members

        public void Draw(ref Canvas paintField, double x, double y)
        {
            var rec = new Ellipse
                          {
                              Width = 20,
                              Height = 20,
                              Fill = new SolidColorBrush(Color.FromRgb(255, 0, 0)),
                              StrokeThickness = 1,
                              Stroke = new SolidColorBrush(Color.FromRgb(255, 0, 0))
                          };
            Canvas.SetLeft(rec, x + 11.2132);
            Canvas.SetTop(rec, y + 11.2132);
            paintField.Children.Add(rec);
        }

        public void Draw(ref Canvas paintField, int fieldNum)
        {
            var rec = new Ellipse
                          {
                              Width = 20,
                              Height = 20,
                              Fill = new SolidColorBrush(Color.FromRgb(255, 0, 0)),
                              StrokeThickness = 1,
                              Stroke = new SolidColorBrush(Color.FromRgb(255, 0, 0))
                          };
            Canvas.SetLeft(rec, fieldNum*30 + 5);
            Canvas.SetTop(rec, 5);
            paintField.Children.Add(rec);
        }

        #endregion
    }
}