﻿using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace MapCreator.RoadElements
{
    internal class CityExit : CrossRoad
    {
        public override void Draw(ref Canvas paintField, int fieldNum)
        {
            var rec = new Rectangle
                          {
                              Width = 30,
                              Height = 30,
                              Fill = new SolidColorBrush(Color.FromRgb(189, 99, 249)),
                              StrokeThickness = 1,
                              Stroke = new SolidColorBrush(Color.FromRgb(189, 99, 249))
                          };
            Canvas.SetLeft(rec, fieldNum*30);
            Canvas.SetTop(rec, 0);
            paintField.Children.Add(rec);
            foreach (var t in OnTheRoad)
            {
                t.Draw(ref paintField, fieldNum);
            }
        }

        public override void Draw(ref Canvas paintField, double x, double y)
        {
            var rec = new Ellipse
                          {
                              Width = 42.4264,
                              Height = 42.4264,
                              Fill = new SolidColorBrush(Color.FromRgb(189, 99, 249)),
                              StrokeThickness = 1,
                              Stroke = new SolidColorBrush(Color.FromRgb(189, 99, 249))
                          };
            Canvas.SetLeft(rec, x);
            Canvas.SetTop(rec, y);
            paintField.Children.Add(rec);
            foreach (var t in OnTheRoad)
            {
                t.Draw(ref paintField, x, y);
            }
        }
    }
}