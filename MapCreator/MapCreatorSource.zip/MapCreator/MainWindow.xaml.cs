﻿using System.Windows;
using Microsoft.Win32;

namespace MapCreator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button1Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog {DefaultExt = ".txt", Filter = "Text documents (.txt)|*.txt"};
            var result = dlg.ShowDialog();
            if (result == true)
            {
                var filename = dlg.FileName;
                canvas1.Children.Clear();
                var myMap = new Map();
                myMap.LoadMap(filename);
                myMap.Draw(ref canvas1);
            }
        }
    }
}