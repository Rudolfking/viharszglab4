﻿using System.Collections.Generic;
using System.Windows.Controls;

namespace MapCreator
{
    internal abstract class Container : IElement
    {
        public readonly List<IElement> OnTheRoad = new List<IElement>();

        #region IElement Members

        public abstract void Draw(ref Canvas paintField, double x, double y);

        public abstract void Draw(ref Canvas paintField, int fieldNum);

        #endregion
    }
}