﻿using System.Windows.Controls;

namespace MapCreator
{
    internal interface IElement
    {
        void Draw(ref Canvas paintField, double x, double y);
        void Draw(ref Canvas paintField, int fieldNum);
    }
}