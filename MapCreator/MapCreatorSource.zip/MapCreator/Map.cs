﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Controls;
using MapCreator.RoadElements;

namespace MapCreator
{
    internal class Map
    {
        private readonly Dictionary<int, CityEntry> _cityEntries = new Dictionary<int, CityEntry>();
        private readonly Dictionary<int, CityExit> _cityExits = new Dictionary<int, CityExit>();
        private readonly Dictionary<int, InterSection> _interSections = new Dictionary<int, InterSection>();
        private readonly List<Road> _roads = new List<Road>();
        private Bank _bank;
        private HidingPlace _hiding;

        public void LoadMap(string fname)
        {
            var inputFile = new FileStream(fname, FileMode.Open);
            var fileReader = new StreamReader(inputFile);
            int coords = 0;
            while (!fileReader.EndOfStream)
            {
                string l = fileReader.ReadLine();
                if (l[0] != '$')
                {
                    CrossRoad first;
                    int rstart = CreateInterSections(l, 0, out first);
                    int pos = l.Length - 1;
                    if (l[pos] == '}')
                    {
                        pos -= pos - l.LastIndexOf('{') + 1;
                    }
                    if (l[pos] == ']')
                        pos -= pos - l.LastIndexOf('[') + 1;
                    int rstop = pos - 1;
                    CrossRoad second;
                    CreateInterSections(l, pos, out second);
                    if (rstop >= rstart) _roads.Add(new Road(l.Substring(rstart, rstop - rstart + 1), first, second));
                }
                else
                {
                    string[] teamString = l.Split(new[] {"$"}, StringSplitOptions.RemoveEmptyEntries);
                    switch (coords)
                    {
                        case 0:
                            _bank.X = Convert.ToDouble(teamString[0]);
                            _bank.Y = Convert.ToDouble(teamString[1]);
                            break;
                        case 1:
                            _hiding.X = Convert.ToDouble(teamString[0]);
                            _hiding.Y = Convert.ToDouble(teamString[1]);
                            break;
                        default:
                            if ((1 < coords) && (coords <= 1 + _cityEntries.Count))
                            {
                                _cityEntries[coords - 2].X = Convert.ToDouble(teamString[0]);
                                _cityEntries[coords - 2].Y = Convert.ToDouble(teamString[1]);
                            }
                            if ((1 + _cityEntries.Count < coords) &&
                                (coords <= 1 + _cityEntries.Count + _cityExits.Count))
                            {
                                _cityExits[coords - 2 - _cityEntries.Count].X = Convert.ToDouble(teamString[0]);
                                _cityExits[coords - 2 - _cityEntries.Count].Y = Convert.ToDouble(teamString[1]);
                            }
                            if ((1 + _cityEntries.Count + _cityExits.Count < coords) &&
                                (coords <= 1 + _cityEntries.Count + _cityExits.Count + _interSections.Count))
                            {
                                _interSections[coords - 2 - _cityEntries.Count - _cityExits.Count].X =
                                    Convert.ToDouble(teamString[0]);
                                _interSections[coords - 2 - _cityEntries.Count - _cityExits.Count].Y =
                                    Convert.ToDouble(teamString[1]);
                            }
                            break;
                    }
                    coords++;
                }
            }
            fileReader.Close();
            inputFile.Close();
        }

        private int CreateInterSections(string l, int pos, out CrossRoad made)
        {
            switch (l[pos])
            {
                case 'E':
                    if (_cityEntries.ContainsKey(Convert.ToInt32(l.Substring(pos+2,l.IndexOf(']',pos+2)-pos-2))))
                    {
                        made = _cityEntries[Convert.ToInt32(l.Substring(pos + 2, l.IndexOf(']', pos + 2) - pos - 2))];
                        if ((l.IndexOf(']', pos) + 1 <= l.Length - 1) && (l[l.IndexOf(']', pos) + 1] == '{'))
                            return l.IndexOf('}', l.IndexOf(']', pos) + 1);
                        return l.IndexOf(']', pos) + 1;
                    }
                    made = new CityEntry();
                    _cityEntries[Convert.ToInt32(l.Substring(pos + 2, l.IndexOf(']', pos + 2) - pos - 2))] = (CityEntry)made;
                    if ((l.IndexOf(']', pos) + 1 <= l.Length - 1) && (l[l.IndexOf(']', pos) + 1] == '{'))
                    {
                        _cityEntries[Convert.ToInt32(l.Substring(pos + 2, l.IndexOf(']', pos + 2) - pos - 2))].OnTheRoad.Add(CreateElement(l[l.IndexOf(']', pos) + 2]));
                        return l.IndexOf('}', l.IndexOf(']', pos) + 1);
                    }
                    return l.IndexOf(']', pos) + 1;
                case 'X':
                    if (_cityExits.ContainsKey(Convert.ToInt32(l.Substring(pos+2,l.IndexOf(']',pos+2)-pos-2))))
                    {
                        made = _cityExits[Convert.ToInt32(l.Substring(pos + 2, l.IndexOf(']', pos + 2) - pos - 2))];
                        if ((l.IndexOf(']', pos) + 1 <= l.Length - 1) && (l[l.IndexOf(']', pos) + 1] == '{'))
                            return l.IndexOf('}', l.IndexOf(']', pos) + 1);
                        return l.IndexOf(']', pos) + 1;
                    }
                    made = new CityExit();
                    _cityExits[Convert.ToInt32(l.Substring(pos + 2, l.IndexOf(']', pos + 2) - pos - 2))] = (CityExit)made;
                    if ((l.IndexOf(']', pos) + 1 <= l.Length - 1) && (l[l.IndexOf(']', pos) + 1] == '{'))
                    {
                        _cityExits[Convert.ToInt32(l.Substring(pos + 2, l.IndexOf(']', pos + 2) - pos - 2))].OnTheRoad.Add(CreateElement(l[l.IndexOf(']', pos) + 2]));
                        return l.IndexOf('}', l.IndexOf(']', pos) + 1);
                    }
                    return l.IndexOf(']', pos) + 1;
                case 'I':
                    if (_interSections.ContainsKey(Convert.ToInt32(l.Substring(pos+2,l.IndexOf(']',pos+2)-pos-2))))
                    {
                        made = _interSections[Convert.ToInt32(l.Substring(pos + 2, l.IndexOf(']', pos + 2) - pos - 2))];
                        if ((l.IndexOf(']', pos) + 1 <= l.Length - 1) && (l[l.IndexOf(']', pos) + 1] == '{'))
                            return l.IndexOf('}', l.IndexOf(']', pos) + 1);
                        return l.IndexOf(']', pos) + 1;
                    }
                    made = new InterSection();
                    _interSections[Convert.ToInt32(l.Substring(pos + 2, l.IndexOf(']', pos + 2) - pos - 2))] = (InterSection)made;
                    if ((l.IndexOf(']', pos) + 1 <= l.Length - 1) && (l[l.IndexOf(']', pos) + 1] == '{'))
                    {
                        _interSections[Convert.ToInt32(l.Substring(pos + 2, l.IndexOf(']', pos + 2) - pos - 2))].OnTheRoad.Add(CreateElement(l[l.IndexOf(']', pos) + 2]));
                        return l.IndexOf('}', l.IndexOf(']', pos) + 1);
                    }
                    return l.IndexOf(']', pos) + 1;
                case 'H':
                    if (_hiding != null)
                    {
                        made = _hiding;
                        if ((pos + 1 <= l.Length - 1) && (l[pos + 1] == '{')) return pos + 4;
                        return pos + 1;
                    }
                    made = new HidingPlace();
                    _hiding = (HidingPlace) made;
                    if ((pos + 1 <= l.Length - 1) && (l[pos + 1] == '{'))
                    {
                        _hiding.OnTheRoad.Add(CreateElement(l[pos + 2]));
                        return pos + 4;
                    }
                    return pos + 1;
                case 'B':
                    if (_bank != null)
                    {
                        made = _bank;
                        if ((pos + 1 <= l.Length - 1) && (l[pos + 1] == '{')) return pos + 4;
                        return pos + 1;
                    }
                    made = new Bank();
                    _bank = (Bank) made;
                    if ((pos + 1 <= l.Length - 1) && (l[pos + 1] == '{'))
                    {
                        _bank.OnTheRoad.Add(CreateElement(l[pos + 2]));
                        return pos + 4;
                    }
                    return pos + 1;
                default:
                    throw new ArgumentException("Not intersection");
            }
        }

        private static IElement CreateElement(char c)
        {
            switch (c)
            {
                case 'F':
                    return new RoadCell();
                case 'S':
                    return new StopSign();
                case 'T':
                    return new TrafficLight();
                case 'C':
                    return new CivilCar();
                case 'P':
                    return new PoliceMan();
                case 'R':
                    return new Robber();
                case 'U':
                    return new Bunny();
                default:
                    return null;
            }
        }

        public void Draw(ref Canvas paintField)
        {
            foreach (var cityEntry in _cityEntries)
            {
                cityEntry.Value.Draw(ref paintField, cityEntry.Value.CornerLeft, cityEntry.Value.CornerTop);
            }
            foreach (var cityExit in _cityExits)
            {
                cityExit.Value.Draw(ref paintField, cityExit.Value.CornerLeft, cityExit.Value.CornerTop);
            }
            foreach (var interSection in _interSections)
            {
                interSection.Value.Draw(ref paintField, interSection.Value.CornerLeft, interSection.Value.CornerTop);
            }
            _bank.Draw(ref paintField, _bank.CornerLeft, _bank.CornerTop);
            _hiding.Draw(ref paintField, _hiding.CornerLeft, _hiding.CornerTop);
            foreach (Road road in _roads)
            {
                paintField.Children.Add(road.Draw());
            }
        }
    }
}