﻿using System;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Media;
using MapCreator.RoadElements;

namespace MapCreator
{
    internal class Road
    {
        private readonly CrossRoad _endCross;
        private readonly List<IElement> _roadCells = new List<IElement>();
        private readonly CrossRoad _startCross;

        public Road(string s, CrossRoad startCross, CrossRoad endCross)
        {
            int i = -1;
            bool containmentParenthesesState = false;
            bool indexParenthesesState = false;
            while (s.Length > 0)
            {
                switch (s[0])
                {
                    case '[':
                        indexParenthesesState = true;
                        break;
                    case ']':
                        indexParenthesesState = false;
                        break;
                    case '{':
                        containmentParenthesesState = true;
                        break;
                    case '}':
                        containmentParenthesesState = false;
                        break;
                    case ',':
                        break;
                    default:
                        if (!indexParenthesesState)
                        {
                            if (containmentParenthesesState)
                            {
                                var contType = _roadCells[i] as Container;
                                if (contType != null)
                                {
                                    contType.OnTheRoad.Add(CreateElement(s[0]));
                                }
                            }
                            else
                            {
                                _roadCells.Add(CreateElement(s[0]));
                                i++;
                            }
                        }
                        break;
                }
                s = s.Remove(0, 1);
            }
            _startCross = startCross;
            _endCross = endCross;
        }

        private static IElement CreateElement(char c)
        {
            switch (c)
            {
                case 'F':
                    return new RoadCell();
                case 'S':
                    return new StopSign();
                case 'T':
                    return new TrafficLight();
                case 'C':
                    return new CivilCar();
                case 'P':
                    return new PoliceMan();
                case 'R':
                    return new Robber();
                case 'U':
                    return new Bunny();
                default:
                    return null;
            }
        }

        public Canvas Draw()
        {
            double x1 = _startCross.X;
            double y1 = _startCross.Y;
            double x2 = _endCross.X;
            double y2 = _endCross.Y;
            double length = Math.Sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1)) - 30;
            var c = new Canvas {Width = _roadCells.Count*30, Height = 30};
            for (int i = 0; i < _roadCells.Count; i++)
            {
                _roadCells[i].Draw(ref c, i);
            }
            if (x1 < x2)
            {
                if (y1 <= y2)
                {
                    double dir = Math.Atan((y2 - y1)/(x2 - x1));
                    double dir2 = (180*dir)/Math.PI;
                    var group = new TransformGroup();
                    group.Children.Add(new ScaleTransform(length/c.Width, 1));
                    group.Children.Add(new RotateTransform(dir2));
                    c.RenderTransform = group;
                    Canvas.SetLeft(c, x1 + Math.Cos(dir - Math.PI/4)*21.2132);
                    Canvas.SetTop(c, y1 + Math.Sin(dir - Math.PI/4)*21.2132);
                }
                else
                {
                    double dir = Math.Atan((y2 - y1)/(x2 - x1));
                    double dir2 = (180*dir)/Math.PI;
                    var group = new TransformGroup();
                    group.Children.Add(new ScaleTransform(length/c.Width, 1));
                    group.Children.Add(new RotateTransform(dir2));
                    c.RenderTransform = group;
                    Canvas.SetLeft(c, x1 + Math.Cos(dir - Math.PI/4)*21.2132);
                    Canvas.SetTop(c, y1 + Math.Sin(dir - Math.PI/4)*21.2132);
                }
            }
            else
            {
                if (x2 < x1)
                {
                    if (y1 <= y2)
                    {
                        double dir = Math.Atan((y2 - y1)/(x2 - x1)) + Math.PI;
                        double dir2 = (180*dir)/Math.PI;
                        var group = new TransformGroup();
                        group.Children.Add(new ScaleTransform(length/c.Width, 1));
                        group.Children.Add(new RotateTransform(dir2));
                        c.RenderTransform = group;
                        Canvas.SetLeft(c, x1 + Math.Cos(dir - Math.PI/4)*21.2132);
                        Canvas.SetTop(c, y1 + Math.Sin(dir - Math.PI/4)*21.2132);
                    }
                    else
                    {
                        double dir = Math.Atan((y2 - y1)/(x2 - x1)) + Math.PI;
                        double dir2 = (180*dir)/Math.PI;
                        var group = new TransformGroup();
                        group.Children.Add(new ScaleTransform(length/c.Width, 1));
                        group.Children.Add(new RotateTransform(dir2));
                        c.RenderTransform = group;
                        Canvas.SetLeft(c, x1 + Math.Cos(dir - Math.PI/4)*21.2132);
                        Canvas.SetTop(c, y1 + Math.Sin(dir - Math.PI/4)*21.2132);
                    }
                }
                else
                {
                    if (y2 > y1)
                    {
                        var group = new TransformGroup();
                        group.Children.Add(new ScaleTransform(length/c.Width, 1));
                        group.Children.Add(new RotateTransform(90));
                        c.RenderTransform = group;
                        Canvas.SetLeft(c, x1 +15);
                        Canvas.SetTop(c, y1 + 15);
                    }
                    else
                    {
                        var group = new TransformGroup();
                        group.Children.Add(new ScaleTransform(length / c.Width, 1));
                        group.Children.Add(new RotateTransform(270));
                        c.RenderTransform = group;
                        Canvas.SetLeft(c, x1-15 );
                        Canvas.SetTop(c, y1- 15);
                    }
                }
            }
            return c;
        }
    }
}